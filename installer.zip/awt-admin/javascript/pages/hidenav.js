$('.top-nav').remove();
$('.main-navbar').remove();