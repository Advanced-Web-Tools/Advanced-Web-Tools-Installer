function moduleSettings(element_id, div_id, modules) {
    
}