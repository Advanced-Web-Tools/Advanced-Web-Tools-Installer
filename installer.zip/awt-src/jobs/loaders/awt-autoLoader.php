<?php


include_once FUNCTIONS.'awt-autoLoader.fun.php';

spl_autoload_register();