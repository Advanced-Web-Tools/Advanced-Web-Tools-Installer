<?php

include_once FUNCTIONS.'awt-getDomain.fun.php';

define("HOSTNAME", getDomainName());